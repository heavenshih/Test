"""Build an editable Rhino exterior study from the supplied single photograph.

Requires Python 3.10+ and rhino3dm. No Rhino installation is needed to generate
the file. All dimensions are approximate metres; front faces negative Y.
"""
from pathlib import Path
import argparse
import json
import math
import random
import sys

TOOLS = Path('/workspace/.model-tools')
if TOOLS.exists():
    sys.path.insert(0, str(TOOLS))
import rhino3dm as r

ROOT = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument('--garage-width', type=float, default=2.5,
                    help='Overall uniform scale reference, metres (default 2.5)')
args = parser.parse_args()
S = args.garage_width / 2.5
assert S > 0
rng = random.Random(5332)
doc = r.File3dm()
doc.ApplicationName = 'Photo-based architectural exterior study'
doc.ApplicationDetails = 'Editable model generated with rhino3dm; estimated dimensions.'
doc.Settings.ModelUnitSystem = r.UnitSystem.Meters
doc.Settings.ModelAbsoluteTolerance = .001 * S
doc.Settings.ModelAngleToleranceDegrees = 1
doc.Strings['Model basis'] = 'Single supplied exterior photo; garage opening assumed 2.5 m. Not a measured survey.'
doc.Strings['Coordinates'] = 'Metres. X left to right, Y front to rear, Z up. Front faces -Y.'
doc.Strings['Scope'] = 'Front exterior interpretation. Rear, sides, depth and interior surfaces inferred. No construction detailing.'
doc.Strings['Scale multiplier'] = str(S)

MAT = {
 'stucco': dict(color=[.88,.875,.83],roughness=.84),
 'charcoal': dict(color=[.075,.086,.10],roughness=.44),
 'siding': dict(color=[.13,.145,.16],roughness=.64),
 'frame': dict(color=[.035,.043,.048],roughness=.28,metallic=.5),
 'timber': dict(color=[.42,.235,.105],roughness=.48),
 'timber_alt': dict(color=[.50,.29,.135],roughness=.5),
 'glass': dict(color=[.73,.85,.88],roughness=.08,transmission=.96),
 'frosted': dict(color=[.96,.83,.53],roughness=.33,transmission=.30,emission=[1,.69,.28],emission_strength=.18),
 'interior': dict(color=[.72,.68,.56],roughness=.85),
 'interior_floor': dict(color=[.39,.29,.19],roughness=.7),
 'concrete': dict(color=[.57,.57,.53],roughness=.88),
 'concrete_light': dict(color=[.71,.70,.65],roughness=.85),
 'mulch': dict(color=[.19,.135,.080],roughness=1),
 'gravel': dict(color=[.38,.365,.32],roughness=1),
 'grass': dict(color=[.20,.27,.105],roughness=.95),
 'leaf': dict(color=[.14,.25,.065],roughness=.85),
 'leaf_light': dict(color=[.26,.36,.10],roughness=.85),
 'leaf_dark': dict(color=[.065,.145,.045],roughness=.9),
 'dry_grass': dict(color=[.47,.43,.21],roughness=.9),
 'bark': dict(color=[.25,.18,.11],roughness=.97),
 'pot': dict(color=[.50,.50,.45],roughness=.86),
 'metal': dict(color=[.43,.45,.44],roughness=.32,metallic=.7),
 'lamp': dict(color=[1,.84,.49],roughness=.28,emission=[1,.70,.30],emission_strength=5),
}
scene = {'materials':MAT,'objects':[],'lights':[],'metadata':{'units':'metres','scale':S}}
materials = {}
for name,p in MAT.items():
    m = r.Material()
    m.Name = name
    m.DiffuseColor = tuple(round(v*255) for v in p['color'])+(255,)
    m.Transparency = p.get('transmission',0) * .78
    m.Shine = (1-p['roughness'])*200
    m.Reflectivity = p.get('metallic',0)*.3
    if 'emission' in p:
        m.EmissionColor = tuple(round(v*255) for v in p['emission'])+(255,)
    materials[name] = doc.Materials.Add(m)

layers={}
def layer(name,mat):
    if name not in layers:
        l=r.Layer(); l.Name=name
        l.Color=tuple(round(v*255) for v in MAT[mat]['color'])+(255,)
        l.RenderMaterialIndex=materials[mat]
        layers[name]=doc.Layers.Add(l)
    return layers[name]

def attrib(name,ln,mat):
    a=r.ObjectAttributes(); a.Name=name; a.LayerIndex=layer(ln,mat)
    a.MaterialIndex=materials[mat]
    a.MaterialSource=r.ObjectMaterialSource.MaterialFromObject
    a.ColorSource=r.ObjectColorSource.ColorFromMaterial
    a.SetUserString('Basis','Photo interpretation; estimated dimensions')
    return a

def register(name,ln,mat,verts,faces,brep=None):
    verts=[[v*S for v in p] for p in verts]
    if brep is not None:
        if S != 1:
            brep.Transform(r.Transform.Scale(r.Point3d(0,0,0),S))
        assert brep.IsValid, name
        doc.Objects.AddBrep(brep,attrib(name,ln,mat))
    else:
        m=r.Mesh()
        for p in verts: m.Vertices.Add(*p)
        for f in faces:
            if len(f)==3: m.Faces.AddFace(*f)
            elif len(f)==4: m.Faces.AddFace(*f)
            else:
                for j in range(1,len(f)-1): m.Faces.AddFace(f[0],f[j],f[j+1])
        m.Normals.ComputeNormals(); m.Compact()
        assert m.IsValid, name
        doc.Objects.AddMesh(m,attrib(name,ln,mat))
    scene['objects'].append(dict(name=name,layer=ln,material=mat,vertices=verts,faces=faces))

def box(name,ln,mat,x0,y0,z0,x1,y1,z1):
    assert x1>x0 and y1>y0 and z1>z0, (name,x0,y0,z0,x1,y1,z1)
    v=[[x0,y0,z0],[x1,y0,z0],[x1,y1,z0],[x0,y1,z0],
       [x0,y0,z1],[x1,y0,z1],[x1,y1,z1],[x0,y1,z1]]
    f=[[0,3,2,1],[0,1,5,4],[1,2,6,5],[2,3,7,6],[3,0,4,7],[4,5,6,7]]
    brep=r.BoundingBox(r.Point3d(x0,y0,z0),r.Point3d(x1,y1,z1)).ToBrep()
    register(name,ln,mat,v,f,brep)

def beam(name,ln,mat,p0,p1,r0,r1=None,n=10):
    r1=r0 if r1 is None else r1
    a=r.Vector3d(*(p1[i]-p0[i] for i in range(3))); length=a.Length()
    a.Unitize()
    ref=r.Vector3d(0,0,1) if abs(a.Z)<.98 else r.Vector3d(1,0,0)
    u=r.Vector3d.CrossProduct(a,ref); u.Unitize()
    v=r.Vector3d.CrossProduct(a,u)
    points=[]
    for p,rad in [(p0,r0),(p1,r1)]:
        for i in range(n):
            t=2*math.pi*i/n
            points.append([p[j]+rad*(math.cos(t)*[u.X,u.Y,u.Z][j]+math.sin(t)*[v.X,v.Y,v.Z][j]) for j in range(3)])
    faces=[list(reversed(range(n))),list(range(n,2*n))]
    faces += [[i,(i+1)%n,(i+1)%n+n,i+n] for i in range(n)]
    brep=None
    if abs(r0-r1)<1e-8:
        plane=r.Plane(r.Point3d(*p0),a)
        circle=r.Circle(r.Point3d(*p0),r0)
        circle.Plane=plane
        brep=r.Cylinder(circle,length).ToBrep(True,True)
    register(name,ln,mat,points,faces,brep)

def wall_open(name,ln,mat,x0,x1,y0,y1,z0,z1,opening):
    ox0,ox1,oz0,oz1=opening
    if ox0>x0: box(name+' left pier',ln,mat,x0,y0,z0,ox0,y1,z1)
    if ox1<x1: box(name+' right pier',ln,mat,ox1,y0,z0,x1,y1,z1)
    if oz0>z0: box(name+' sill wall',ln,mat,ox0,y0,z0,ox1,y1,oz0)
    if oz1<z1: box(name+' header',ln,mat,ox0,y0,oz1,ox1,y1,z1)

def slats(name,ln,x0,x1,y0,y1,z0,z1,pitch=.085,mat='siding'):
    num=math.ceil((z1-z0)/pitch)
    for i in range(num):
        za=z0+i*pitch; zb=min(za+pitch-.009,z1)
        if zb>za: box(f'{name} course {i+1:02}',ln,mat,x0,y0,za,x1,y1,zb)

def window(name,x0,x1,y,z0,z1,mullions,ln='05 Windows and glazing'):
    t=.066; d=.10
    box(name+' left frame',ln,'frame',x0,y,z0,x0+t,y+d,z1)
    box(name+' right frame',ln,'frame',x1-t,y,z0,x1,y+d,z1)
    box(name+' head frame',ln,'frame',x0+t,y,z1-t,x1-t,y+d,z1)
    box(name+' sill frame',ln,'frame',x0+t,y,z0,x1-t,y+d,z0+t)
    bounds=[x0+t]+mullions+[x1-t]
    for i,x in enumerate(mullions):
        box(name+f' mullion {i+1}',ln,'frame',x-t/2,y-.006,z0+t,x+t/2,y+d+.006,z1-t)
    for i,(a,b) in enumerate(zip(bounds[:-1],bounds[1:])):
        a += t/2 if i else 0; b -= t/2 if i<len(bounds)-2 else 0
        box(name+f' glass pane {i+1}',ln,'glass',a,y+.048,z0+t,b,y+.065,z1-t)
    box(name+' projecting sill',ln,'charcoal',x0-.025,y-.025,z0-.025,x1+.025,y+.20,z0)

def boards(name,x0,x1,y0,y1,z,ln='04 Timber soffits and porch',width=.14):
    count=math.ceil((x1-x0)/width)
    for i in range(count):
        a=x0+i*width; b=min(a+width-.005,x1)
        if b>a: box(name+f' board {i+1:02}',ln,'timber_alt' if i%4==1 else 'timber',a,y0,z,b,y1,z+.024)

def downlight(name,x,y,z):
    beam(name+' trim','08 Lighting','frame',(x,y,z-.012),(x,y,z),.067,n=20)
    beam(name+' lens','08 Lighting','lamp',(x,y,z-.018),(x,y,z-.012),.046,n=20)
    scene['lights'].append(dict(location=[x*S,y*S,(z-.06)*S],color=[1,.72,.38],energy=38*S*S,size=.18*S))

# SITE, GROUND AND FOUNDATIONS
box('Site base','00 Site','gravel',-2.1,-6.8,-.22,12.5,11.2,-.055)
box('Front garden mulch bed','00 Site','mulch',5.8,-5.7,-.05,12.0,-.05,.015)
box('Entry green joints and lawn','00 Site','grass',3.3,-6.5,-.045,5.8,-.9,.015)
box('Garage side planting strip','00 Site','mulch',-.35,-1.7,-.045,.4,-.04,.015)
box('Driveway slab','00 Site','concrete_light',.10,-6.65,-.025,3.25,.22,.055)
for yy in [-4.25,-1.9]:
    box('Driveway control joint','00 Site','gravel',.1,yy,.055,3.25,yy+.014,.06)
for i,yy in enumerate([-5.8,-4.65,-3.50,-2.35,-1.20]):
    box(f'Entry stepping slab {i+1}','00 Site','concrete_light',3.48,yy,.025,5.63,yy+.70,.105)
box('Lower concrete step','00 Site','concrete',3.53,-.51,.02,5.65,.16,.17)
box('Upper concrete step','00 Site','concrete_light',3.53,-.20,.17,5.65,.45,.32)

# LOWER ENVELOPE: REAL WALL OPENINGS, SIMPLE INFERRED REAR.
box('Ground floor slab','01 Walls and structure','concrete',0,0,.055,10.1,10.2,.25)
wall_open('Garage front','01 Walls and structure','stucco',0,3.5,0,.24,.055,3.79,(.50,3.0,.055,2.60))
box('Garage left wall','01 Walls and structure','stucco',0,.24,.055,.22,10.2,3.79)
box('Garage right return','01 Walls and structure','stucco',3.28,.24,.25,3.5,6.0,3.52)
wall_open('Recessed entry','01 Walls and structure','stucco',3.5,5.7,1.35,1.57,.34,3.42,(4.35,5.39,.34,2.52))
box('Entry right return','01 Walls and structure','stucco',5.7,.1,.25,5.92,1.57,3.42)
wall_open('Living front','01 Walls and structure','stucco',5.7,10.1,.10,.34,.055,3.42,(7.83,9.88,1.10,2.96))
box('Living right external wall','01 Walls and structure','stucco',9.88,.34,.055,10.1,10.2,3.78)
box('Inferred rear ground wall','13 Inferred rear and interiors','stucco',.22,9.98,.25,9.88,10.2,3.78)
box('Living room ceiling and flat roof','02 Roofs and fascias','stucco',3.5,1.57,3.46,9.88,9.98,3.76)
box('Garage roof slab','02 Roofs and fascias','stucco',0,.24,3.55,3.5,9.98,3.77)
box('Garage front coping','02 Roofs and fascias','charcoal',-.025,-.025,3.79,3.5,.255,3.825)
box('Garage left coping','02 Roofs and fascias','charcoal',-.025,.255,3.79,.245,10.23,3.825)
box('Living right coping','02 Roofs and fascias','charcoal',9.855,.34,3.78,10.125,10.23,3.825)
box('Rear coping','02 Roofs and fascias','charcoal',0,9.955,3.78,10.1,10.225,3.825)

# LONG GROUND-FLOOR CANOPY.
box('Canopy structural slab','02 Roofs and fascias','charcoal',3.17,-.48,3.44,11.10,1.75,3.99)
box('Canopy top cap','02 Roofs and fascias','frame',3.15,-.50,3.99,11.12,1.77,4.025)
boards('Entry canopy soffit',3.25,11.02,-.44,1.69,3.407)
for i,(x,y) in enumerate([(4.0,-.27),(6.45,-.27),(9.0,-.27),(4.35,.91)]):
    downlight(f'Canopy downlight {i+1}',x,y,3.405)

# UPPER BOX AND LOWER LEFT CHARCOAL VOLUME.
box('Upper floor slab','01 Walls and structure','concrete',1.64,1.6,3.76,8.08,9.6,3.93)
wall_open('Main upper white facade','01 Walls and structure','stucco',3.86,8.08,1.03,1.25,4.025,6.43,(5.10,7.80,4.56,6.02))
box('Upper right wall','01 Walls and structure','stucco',7.86,1.25,3.93,8.08,9.60,6.43)
box('Upper rear wall','13 Inferred rear and interiors','stucco',3.86,9.38,3.93,7.86,9.60,6.43)
box('Upper left dark return backing','03 Horizontal cladding','charcoal',3.45,.90,4.025,3.86,9.6,6.47)
slats('Main upper left front return','03 Horizontal cladding',3.44,3.87,.855,.90,4.025,6.47,.078)
for i in range(32):
    za=4.025+i*.078; zb=min(za+.069,6.47)
    if zb>za: box(f'Upper left side cladding {i+1:02}','03 Horizontal cladding','siding',3.415,.90,za,3.45,9.6,zb)
wall_open('Upper left box facade','03 Horizontal cladding','charcoal',1.64,3.45,1.68,1.90,3.83,5.83,(1.83,2.79,4.10,5.40))
box('Upper left box outer wall','03 Horizontal cladding','charcoal',1.64,1.90,3.83,1.86,9.38,5.83)
box('Upper left box rear wall','13 Inferred rear and interiors','charcoal',1.86,9.16,3.83,3.45,9.38,5.83)
for i in range(math.ceil(2.0/.078)):
    za=3.83+i*.078; zb=min(za+.068,5.83)
    if zb<=za: continue
    spans=[(1.64,1.83),(2.79,3.45)] if zb>4.10 and za<5.4 else [(1.64,3.45)]
    for j,(a,b) in enumerate(spans):
        box(f'Left box front siding {i:02}-{j}','03 Horizontal cladding','siding',a,1.64,za,b,1.68,zb)
    box(f'Left box side siding {i:02}','03 Horizontal cladding','siding',1.60,1.68,za,1.64,9.38,zb)
box('Lower upper-box roof','02 Roofs and fascias','charcoal',1.59,1.63,5.83,3.5,9.43,5.90)

# UPPER ROOF WRAP AND TIMBER OVERHANGS.
box('Upper main roof slab','02 Roofs and fascias','charcoal',3.44,.30,6.47,8.82,9.88,6.89)
box('Upper main roof cap','02 Roofs and fascias','frame',3.425,.285,6.89,8.835,9.895,6.925)
slats('Upper roof front fascia','03 Horizontal cladding',3.44,8.82,.265,.30,6.47,6.89,.078)
for i in range(6):
    za=6.47+i*.078; zb=min(za+.068,6.89)
    if zb>za: box(f'Roof right edge siding {i:02}','03 Horizontal cladding','siding',8.82,.3,za,8.855,9.88,zb)
boards('Upper front soffit',3.88,8.79,.32,1.03,6.435)
boards('Upper right soffit',8.085,8.79,1.03,9.85,6.435)

# FENESTRATION.
window('Upper main window',5.10,7.80,1.025,4.56,6.02,[5.82,7.10])
window('Upper left window',1.83,2.79,1.625,4.10,5.40,[])
window('Living front window',7.83,9.88,.095,1.10,2.96,[8.57])
box('Living window left transom','05 Windows and glazing','frame',7.896,.088,2.405,8.537,.204,2.45)
slats('Living window lower cladding','03 Horizontal cladding',7.82,10.10,.045,.095,.08,1.085,.085)
box('Garage door backing','06 Garage and entry door','charcoal',.50,.095,.06,3.0,.19,2.60)
slats('Garage door slats','06 Garage and entry door',.55,2.95,.053,.095,.09,2.55,.067)
box('Garage door left jamb','06 Garage and entry door','frame',.48,-.012,.055,.55,.115,2.625)
box('Garage door right jamb','06 Garage and entry door','frame',2.95,-.012,.055,3.02,.115,2.625)
box('Garage door head','06 Garage and entry door','frame',.48,-.012,2.55,3.02,.115,2.625)
for i,x in enumerate([1.11,2.43]):
    downlight(f'Garage door downlight {i+1}',x,.008,2.58)

box('Entry threshold','06 Garage and entry door','charcoal',4.32,1.25,.33,5.42,1.61,.37)
window('Entry door perimeter',4.35,5.39,1.32,.36,2.52,[],ln='06 Garage and entry door')
# Replace the clear glass pane with the door's frosted luminous panel.
for o in doc.Objects:
    if o.Attributes.Name=='Entry door perimeter glass pane 1':
        o.Attributes.MaterialIndex=materials['frosted']
for o in scene['objects']:
    if o['name']=='Entry door perimeter glass pane 1': o['material']='frosted'
box('Door bottom rail','06 Garage and entry door','frame',4.40,1.309,.36,5.34,1.44,.53)
beam('Entry door pull','06 Garage and entry door','metal',(5.26,1.24,1.05),(5.26,1.24,1.45),.014)
for z in [1.08,1.42]: beam('Door pull mount','06 Garage and entry door','metal',(5.26,1.24,z),(5.26,1.32,z),.01)
boards('Raised entry porch',3.53,5.7,.38,1.35,.322,width=.12)
box('Timber porch front riser','04 Timber soffits and porch','timber',3.53,.345,.18,5.7,.385,.346)
box('Entry doormat','07 Exterior details','gravel',4.40,.70,.349,5.30,1.14,.363)
box('Address plaque','07 Exterior details','metal',6.05,.055,2.40,6.50,.09,2.58)
box('Wall sconce','08 Lighting','frame',6.22,-.01,2.86,6.34,.12,2.98)
box('Wall sconce bottom glow','08 Lighting','lamp',6.235,.00,2.851,6.325,.09,2.86)
scene['lights'].append(dict(location=[6.28*S,-.04*S,2.80*S],color=[1,.73,.42],energy=8*S*S,size=.10*S))
# Address curves are editable Rhino geometry; geometric seven-segment lettering renders too.
segments={'0':'abcedf','1':'bc','2':'abged','3':'abgcd','4':'fgbc','5':'afgcd','6':'afgecd','7':'abc','8':'abcdefg','9':'abfgcd'}
seg={'a':((0,1),(.65,1)),'b':((.65,1),(.65,.5)),'c':((.65,.5),(.65,0)),
     'd':((0,0),(.65,0)),'e':((0,.5),(0,0)),'f':((0,1),(0,.5)),'g':((0,.5),(.65,.5))}
for i,ch in enumerate('5322'):
    for s in segments[ch]:
        p,q=seg[s]; x=6.085+i*.095; z=2.425
        beam(f'Address {i+1} segment {s}','07 Exterior details','frame',(x+p[0]*.09,.044,z+p[1]*.12),(x+q[0]*.09,.044,z+q[1]*.12),.004,n=6)

# SHALLOW ROOM CONTEXT THROUGH GLASS, NO CLAIM TO A FLOOR PLAN.
box('Upper room back surface','13 Inferred rear and interiors','interior',3.87,4.75,3.93,7.86,4.86,6.43)
box('Upper room floor','13 Inferred rear and interiors','interior_floor',3.87,1.25,3.93,7.86,4.75,3.96)
box('Upper room ceiling','13 Inferred rear and interiors','interior',3.87,1.25,6.405,7.86,4.75,6.43)
box('Upper left room back surface','13 Inferred rear and interiors','interior',1.86,3.45,3.93,3.44,3.55,5.83)
box('Living room back surface','13 Inferred rear and interiors','interior',5.93,4.50,.25,9.88,4.62,3.46)
box('Living room floor','13 Inferred rear and interiors','interior_floor',5.93,.34,.25,9.88,4.50,.28)
box('Door interior background','13 Inferred rear and interiors','interior',3.51,3.00,.25,5.69,3.10,3.42)
for name,x,y,z in [('Upper room',6.4,2.9,6.36),('Living room',8.8,2.4,3.39),('Left room',2.3,2.5,5.78),('Entry',4.9,2.3,3.35)]:
    scene['lights'].append(dict(location=[x*S,y*S,z*S],color=[1,.80,.50],energy=80*S*S,size=.8*S))
    beam(name+' ceiling lamp','08 Lighting','lamp',(x,y,z),(x,y,z+.018),.075,n=16)

# BOUNDARY FENCING.
for i,x in enumerate([-2.0,-.65]):
    box(f'Left fence post {i+1}','09 Fences','charcoal',x,.55,0,x+.09,.65,1.88)
slats('Left boundary fence','09 Fences',-2.1,0,.42,.53,.10,1.85,.15)
for i,y in enumerate([.5,2.8,5.1,7.4,9.7]):
    box(f'Right fence post {i+1}','09 Fences','charcoal',11.60,y,0,11.70,y+.09,1.85)
for i in range(12):
    za=.10+i*.15
    box(f'Right fence horizontal board {i+1}','09 Fences','siding',11.55,.5,za,11.60,10.4,za+.14)

# PLANT GEOMETRY: INDIVIDUALLY LAYERED LOW-POLYGON LANDSCAPE MESHES.
def ellipsoid(name,center,radii,mat='leaf',ln='11 Shrubs and trees',rings=6,n=10):
    cx,cy,cz=center; rx,ry,rz=radii
    verts=[[cx,cy,cz+rz],[cx,cy,cz-rz]]
    for i in range(1,rings):
        ph=math.pi*i/rings
        for j in range(n):
            th=2*math.pi*j/n
            verts.append([cx+rx*math.sin(ph)*math.cos(th),cy+ry*math.sin(ph)*math.sin(th),cz+rz*math.cos(ph)])
    faces=[]
    for j in range(n): faces.append([0,2+j,2+(j+1)%n])
    for i in range(rings-2):
        for j in range(n):
            a=2+i*n+j; b=2+i*n+(j+1)%n
            faces.append([a,a+n,b+n,b])
    base=2+(rings-2)*n
    for j in range(n): faces.append([1,base+(j+1)%n,base+j])
    register(name,ln,mat,verts,faces)

def shrub(name,x,y,radius,height):
    for i in range(8):
        th=rng.uniform(0,2*math.pi); rr=rng.uniform(0,radius*.6)
        rad=radius*rng.uniform(.40,.72)
        ellipsoid(name+f' foliage {i+1}',(x+math.cos(th)*rr,y+math.sin(th)*rr,height*rng.uniform(.35,.70)),(rad,rad,height*rng.uniform(.32,.55)),['leaf','leaf_light','leaf_dark'][i%3])

def grass(name,x,y,height,radius):
    verts=[]; faces=[]
    for i in range(55):
        th=rng.uniform(0,2*math.pi); rr=radius*rng.uniform(0,.35)
        h=height*rng.uniform(.45,1.10); lean=radius*rng.uniform(.55,1.5)
        bx=x+rr*math.cos(th); by=y+rr*math.sin(th); w=rng.uniform(.009,.020)
        dx=math.cos(th); dy=math.sin(th); start=len(verts)
        for k in range(4):
            t=k/3; side=w*(1-t*.94)
            px=bx+dx*lean*t*t; py=by+dy*lean*t*t; zz=.03+h*(t-.15*t*t)
            verts.extend([[px-dy*side,py+dx*side,zz],[px+dy*side,py-dx*side,zz]])
        for k in range(3):
            a=start+2*k; faces.append([a,a+1,a+3,a+2])
    register(name,'10 Ornamental grasses','dry_grass' if rng.random()<.28 else 'grass',verts,faces)

for i,(x,y,h,rad) in enumerate([(6.1,-1.1,.7,.32),(7.2,-3.0,.65,.30),(8.6,-4.4,.75,.40),(10.6,-2.5,.8,.35),(6.5,-5.1,.55,.35),(4.0,-5.9,.65,.32),(2.2,-5.8,.5,.35),(11.3,-4.8,.65,.32),(9.8,-.6,.5,.23),(5.9,-3.7,.65,.28)]):
    grass(f'Grass clump {i+1:02}',x,y,h,rad)
for i,(x,y,rad,h) in enumerate([(9.8,-1.1,.50,.65),(11.1,-.5,.5,.95),(6.0,-.3,.3,.5),(10.9,-4.5,.4,.55),(7.8,-.6,.28,.45),(-.1,-.6,.25,.38),(11.0,-5.6,.5,.65)]):
    shrub(f'Garden shrub {i+1}',x,y,rad,h)

# Young tree in front of the lower right wall, with airy crown.
beam('Front tree trunk','11 Shrubs and trees','bark',(8.05,-1.45,.02),(8.03,-1.44,2.95),.045,.020,n=10)
for i in range(15):
    th=rng.uniform(0,2*math.pi); zz=rng.uniform(1.15,2.85); rr=rng.uniform(.25,.60)
    end=(8.03+math.cos(th)*rr,-1.44+math.sin(th)*rr,zz+.28)
    beam(f'Young tree branch {i}','11 Shrubs and trees','bark',(8.03,-1.44,zz-.26),end,.014,.005,n=6)
    ellipsoid(f'Young tree leaves {i}',end,(.19,.14,.29),'leaf' if i%3 else 'leaf_light',rings=5,n=7)
for x in [7.75,8.34]: beam('Tree support stake','11 Shrubs and trees','bark',(x,-1.45,.01),(x,-1.45,1.55),.017,n=8)
beam('Tree support tie','11 Shrubs and trees','charcoal',(7.75,-1.45,1.35),(8.34,-1.45,1.35),.008,n=6)

# Two slender cypresses behind the left mass, matching the photograph's context.
for j,(x,y,h) in enumerate([(1.2,5.6,8.1),(.70,6.6,7.5)]):
    beam(f'Cypress {j+1} trunk','12 Background planting','bark',(x,y,0),(x,y,h*.91),.09,.035,n=8)
    for k in range(8):
        zz=1.7+k*(h-2.15)/7; rr=.43*(1-.58*k/7)
        ellipsoid(f'Cypress {j+1} crown {k+1}',(x,y,zz),(rr,rr,.95 if k<6 else .67),'leaf_dark','12 Background planting',rings=6,n=9)

# Porch pots and small loose planting stones.
for i,(x,y,rad,h) in enumerate([(3.65,.20,.16,.30),(4.05,1.12,.10,.20),(4.17,1.15,.075,.16)]):
    base=.35 if y>.4 else .17
    beam(f'Planter {i+1}','07 Exterior details','pot',(x,y,base),(x,y,base+h),rad*.73,rad,n=20)
    beam(f'Planter {i+1} soil','07 Exterior details','mulch',(x,y,base+h-.009),(x,y,base+h),rad*.86,n=20)
    for j in range(6):
        th=j*2*math.pi/6
        ellipsoid(f'Potted plant {i+1} leaves {j+1}',(x+math.cos(th)*rad*.8,y+math.sin(th)*rad*.8,base+h+.10),(.09,.07,.18),'leaf',rings=4,n=7)
for i in range(55):
    x=rng.uniform(6.05,11.7); y=rng.uniform(-5.6,-.1); rad=rng.uniform(.018,.045)
    ellipsoid(f'Garden stone {i+1}',(x,y,.035),(rad*1.4,rad,rad*.6),'gravel','00 Site',rings=3,n=5)

# Named camera views retained in the native .3dm.
def view(name,eye,target,parallel=False,span=10):
    v=r.ViewInfo(); v.Name=name; vp=v.Viewport
    vp.SetCameraLocation(r.Point3d(*(x*S for x in eye)))
    vp.SetCameraDirection(r.Vector3d(*((target[i]-eye[i])*S for i in range(3))))
    vp.SetCameraUp(r.Vector3d(0,0,1))
    vp.TargetPoint=r.Point3d(*(x*S for x in target))
    if parallel:
        vp.ChangeToParallelProjection(True)
        vp.SetFrustum(-span*S,span*S,-span*.70*S,span*.70*S,.1*S,150*S)
    else:
        vp.ChangeToPerspectiveProjection(10*S,True,50)
        vp.SetFrustum(-.15,.15,-.105,.105,.5,150*S)
    vp.SetScreenPort((0,1600,0,1120,0,1))
    doc.NamedViews.Add(v)
    return v

v=view('01 Front perspective',(12,-27,8.7),(5.1,2.0,2.8))
doc.Views.Add(v)
view('02 Front elevation',(5.05,-25,3.5),(5.05,1,3.5),True,7.7)
view('03 Axonometric',(18,-21,15),(5,2,2.8),True,12)
view('04 Rear - inferred',(16,26,12),(5,5,3),True,11)
out=ROOT/'single_family_home.3dm'
assert doc.Write(str(out),7), 'Rhino write failed'
(ROOT/'scene.json').write_text(json.dumps(scene,separators=(',',':')))
print(json.dumps({'file':str(out),'objects':len(doc.Objects),'layers':len(doc.Layers),
                  'materials':len(doc.Materials),'named_views':len(doc.NamedViews),
                  'size_bytes':out.stat().st_size,'garage_width_m':args.garage_width},indent=2))
