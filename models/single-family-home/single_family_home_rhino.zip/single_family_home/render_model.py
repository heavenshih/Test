"""Render the actual mesh scene exported alongside the editable Rhino model.

Usage:
  blender -b --python render_model.py -- --scene scene.json --output .

The geometry in scene.json is the source of truth. Only cameras, lights, a
surrounding presentation ground and material surface detail are added here.
"""

import argparse
import json
import math
import os
import sys
from pathlib import Path

import bpy
import _cycles
from mathutils import Vector


def arguments():
    parser = argparse.ArgumentParser()
    parser.add_argument("--scene", default=str(Path(__file__).with_name("scene.json")))
    parser.add_argument("--output", default=str(Path(__file__).parent))
    parser.add_argument("--views", default="hero,front")
    parser.add_argument("--samples", type=int, default=48)
    parser.add_argument("--resolution", type=int, default=1600)
    return parser.parse_args(sys.argv[sys.argv.index("--") + 1:] if "--" in sys.argv else [])


def linear(value):
    return value / 12.92 if value <= 0.04045 else ((value + 0.055) / 1.055) ** 2.4


def rgba(color):
    return tuple(linear(float(v)) for v in color[:3]) + (1.0,)


def make_material(name, spec):
    material = bpy.data.materials.new(name)
    material.use_nodes = True
    material.diffuse_color = rgba(spec.get("color", [0.7, 0.7, 0.7]))
    nodes = material.node_tree.nodes
    links = material.node_tree.links
    bsdf = nodes.get("Principled BSDF")
    bsdf.inputs["Base Color"].default_value = material.diffuse_color
    bsdf.inputs["Roughness"].default_value = float(spec.get("roughness", 0.5))
    bsdf.inputs["Metallic"].default_value = float(spec.get("metallic", 0.0))
    transmission = float(spec.get("transmission", 0.0))
    bsdf.inputs["Transmission Weight"].default_value = transmission
    if transmission:
        bsdf.inputs["IOR"].default_value = 1.45
    if "emission" in spec:
        bsdf.inputs["Emission Color"].default_value = rgba(spec["emission"])
        bsdf.inputs["Emission Strength"].default_value = spec.get("emission_strength", 2.0)

    key = name.lower()
    is_wood = any(word in key for word in ("timber", "wood", "cedar", "oak", "soffit"))
    is_plaster = any(word in key for word in ("stucco", "plaster", "render", "white"))
    is_stone = any(word in key for word in ("concrete", "gravel", "stone", "paver", "soil", "mulch"))
    if not transmission and (is_wood or is_plaster or is_stone):
        geometry = nodes.new("ShaderNodeNewGeometry")
        noise = nodes.new("ShaderNodeTexNoise")
        noise.inputs["Detail"].default_value = 3.0
        noise.inputs["Roughness"].default_value = 0.68
        if is_wood:
            scale = nodes.new("ShaderNodeVectorMath")
            scale.operation = "MULTIPLY"
            scale.inputs[1].default_value = (4.0, 90.0, 40.0)
            links.new(geometry.outputs["Position"], scale.inputs[0])
            links.new(scale.outputs["Vector"], noise.inputs["Vector"])
            noise.inputs["Scale"].default_value = 1.0
        else:
            links.new(geometry.outputs["Position"], noise.inputs["Vector"])
            noise.inputs["Scale"].default_value = 150.0 if is_plaster else 22.0
        ramp = nodes.new("ShaderNodeValToRGB")
        base = spec.get("color", [0.7, 0.7, 0.7])
        variation = 0.10 if is_wood else (0.018 if is_plaster else 0.075)
        ramp.color_ramp.elements[0].position = 0.12
        ramp.color_ramp.elements[0].color = rgba([max(0.0, c * (1.0 - variation)) for c in base])
        ramp.color_ramp.elements[1].position = 0.88
        ramp.color_ramp.elements[1].color = rgba([min(1.0, c * (1.0 + variation)) for c in base])
        links.new(noise.outputs["Fac"], ramp.inputs["Fac"])
        links.new(ramp.outputs["Color"], bsdf.inputs["Base Color"])
        bump = nodes.new("ShaderNodeBump")
        bump.inputs["Strength"].default_value = 0.15 if is_wood else 0.12
        bump.inputs["Distance"].default_value = 0.0015 if is_plaster else 0.006
        links.new(noise.outputs["Fac"], bump.inputs["Height"])
        links.new(bump.outputs["Normal"], bsdf.inputs["Normal"])
    return material


def aim(obj, target):
    direction = Vector(target) - obj.location
    obj.rotation_euler = direction.to_track_quat("-Z", "Y").to_euler()


def add_light(name, location, color, energy, size=1.0, target=None, kind="AREA"):
    data = bpy.data.lights.new(name, kind)
    data.energy = energy
    data.color = color
    if kind == "AREA":
        data.shape = "DISK"
        data.size = size
    elif kind == "POINT":
        data.shadow_soft_size = size
    elif kind == "SUN":
        data.angle = math.radians(12)
    obj = bpy.data.objects.new(name, data)
    bpy.context.collection.objects.link(obj)
    obj.location = location
    if target is not None:
        aim(obj, target)
    return obj


def camera(name, location, target, *, orthographic=None, lens=50):
    data = bpy.data.cameras.new(name)
    obj = bpy.data.objects.new(name, data)
    bpy.context.collection.objects.link(obj)
    obj.location = location
    data.lens = lens
    data.clip_end = 1000
    if orthographic:
        data.type = "ORTHO"
        data.ortho_scale = orthographic
    aim(obj, target)
    return obj


def main():
    args = arguments()
    output = Path(args.output).resolve()
    output.mkdir(parents=True, exist_ok=True)
    with open(args.scene, "r", encoding="utf-8") as stream:
        source = json.load(stream)
    presentation_scale = float(source.get("metadata", {}).get("scale", 1.0))

    bpy.ops.object.select_all(action="SELECT")
    bpy.ops.object.delete(use_global=False)
    for data in list(bpy.data.materials):
        bpy.data.materials.remove(data)

    scene = bpy.context.scene
    scene.unit_settings.system = "METRIC"
    scene.unit_settings.length_unit = "METERS"
    scene.render.engine = "CYCLES"
    scene.cycles.device = "CPU"
    denoiser_available = bool(getattr(_cycles, "with_openimagedenoise", False))
    scene.cycles.samples = args.samples if denoiser_available or args.samples == 1 else max(args.samples, 128)
    scene.cycles.use_denoising = denoiser_available
    scene.cycles.use_adaptive_sampling = True
    scene.cycles.adaptive_threshold = 0.025 if denoiser_available else 0.012
    scene.cycles.seed = 22
    scene.cycles.max_bounces = 10
    scene.cycles.diffuse_bounces = 4
    scene.cycles.glossy_bounces = 4
    scene.cycles.transmission_bounces = 8
    scene.cycles.transparent_max_bounces = 8
    scene.cycles.sample_clamp_indirect = 5.0
    scene.render.threads_mode = "FIXED"
    scene.render.threads = 8
    scene.render.image_settings.file_format = "PNG"
    scene.render.image_settings.color_mode = "RGB"
    scene.render.image_settings.color_depth = "8"
    scene.render.resolution_percentage = 100
    scene.render.film_transparent = False
    scene.view_settings.view_transform = "AgX"
    scene.view_settings.look = "AgX - Medium High Contrast"
    scene.view_settings.exposure = 0.4

    mats = {name: make_material(name, spec) for name, spec in source["materials"].items()}
    collections = {}
    for item in source["objects"]:
        layer = item.get("layer", "House")
        if layer not in collections:
            collection = bpy.data.collections.new(layer)
            scene.collection.children.link(collection)
            collections[layer] = collection
        mesh = bpy.data.meshes.new(item["name"] + " geometry")
        mesh.from_pydata(item["vertices"], [], item["faces"])
        mesh.validate(clean_customdata=False)
        mesh.update()
        obj = bpy.data.objects.new(item["name"], mesh)
        collections[layer].objects.link(obj)
        mat = mats.get(item.get("material"))
        if mat:
            obj.data.materials.append(mat)
        obj["Rhino layer"] = layer
        # Tiny edge radii make highlights readable without changing the design.
        if len(mesh.polygons) <= 12 and not any(w in item["name"].lower() for w in ("glass", "glazing", "leaf", "grass")):
            bevel = obj.modifiers.new("Presentation edge softness", "BEVEL")
            bevel.width = 0.004 * presentation_scale
            bevel.segments = 2
            bevel.limit_method = "ANGLE"

    world = bpy.data.worlds.new("Cool clear evening")
    scene.world = world
    world.use_nodes = True
    background = world.node_tree.nodes.get("Background")
    background.inputs["Color"].default_value = (0.46, 0.61, 0.82, 1.0)
    background.inputs["Strength"].default_value = 0.48
    # Keep the sky blue in the photograph while retaining soft environment fill.
    sky = world.node_tree.nodes.new("ShaderNodeBackground")
    sky.name = "Visible blue sky"
    sky.inputs["Color"].default_value = (0.12, 0.30, 0.60, 1.0)
    sky.inputs["Strength"].default_value = 0.8
    light_path = world.node_tree.nodes.new("ShaderNodeLightPath")
    sky_mix = world.node_tree.nodes.new("ShaderNodeMixShader")
    world.node_tree.links.new(light_path.outputs["Is Camera Ray"], sky_mix.inputs[0])
    world.node_tree.links.new(background.outputs["Background"], sky_mix.inputs[1])
    world.node_tree.links.new(sky.outputs["Background"], sky_mix.inputs[2])
    world.node_tree.links.new(sky_mix.outputs[0], world.node_tree.nodes.get("World Output").inputs["Surface"])

    ground_material = make_material("Presentation ground", {"color": [0.70, 0.72, 0.71], "roughness": 0.95})
    bpy.ops.mesh.primitive_plane_add(size=200, location=(5, 2, -0.13))
    ground = bpy.context.object
    ground.name = "Presentation ground beyond the modeled site"
    ground.data.materials.append(ground_material)

    add_light("Low afternoon sun", (-12, -16, 18), (1.0, 0.89, 0.75), 2.0, target=(5, 2, 0), kind="SUN")
    fill_lights = [
        add_light("Facade soft light", (0, -13, 13), (1.0, 0.91, 0.79), 1100, 11, (5, 0, 3)),
        add_light("Sky fill", (12, 5, 14), (0.67, 0.80, 1.0), 1300, 10, (5, 3, 3)),
    ]
    for fill in fill_lights:
        fill.data.specular_factor = 0.0
        fill.visible_glossy = False
    # Geometry and architectural lights are already scaled by the model builder.
    # Scale only the presentation rig here for alternate garage-width inputs.
    ground.location *= presentation_scale
    ground.scale *= presentation_scale
    for rig_light in [bpy.data.objects["Low afternoon sun"]] + fill_lights:
        rig_light.location *= presentation_scale
        if rig_light.data.type != "SUN":
            rig_light.data.energy *= presentation_scale ** 2
            rig_light.data.size *= presentation_scale
    for index, light in enumerate(source.get("lights", [])):
        light_size = light.get("size", 0.14)
        # Interior point lights sit just below ceilings. Keep their luminous
        # source compact so it does not appear as a large disk through glazing.
        if light.get("type", "POINT") == "POINT" and light_size > 0.35 * presentation_scale:
            light_size = 0.055 * presentation_scale
        add_light(
            light.get("name", "Architectural light %03d" % index),
            light["location"],
            light.get("color", [1.0, 0.70, 0.38]),
            light.get("energy", 30),
            light_size,
            light.get("target"),
            light.get("type", "POINT"),
        )

    cameras = {
        "hero": camera("Hero architectural axonometric", (15, -23, 12), (5, 2, 2), orthographic=21),
        "front": camera("Front reference view", (7.4, -22, 2.5), (5, 1, 3.3), lens=50),
    }
    for view_camera in cameras.values():
        view_camera.location *= presentation_scale
        if view_camera.data.type == "ORTHO":
            view_camera.data.ortho_scale *= presentation_scale
    scene.camera = cameras["hero"]
    scene.render.resolution_x = args.resolution
    scene.render.resolution_y = round(args.resolution * 0.75)
    bpy.ops.wm.save_as_mainfile(filepath=str(output / "house_visualization.blend"))
    for name in args.views.split(","):
        name = name.strip()
        if name not in cameras:
            raise ValueError("Unknown view: " + name)
        scene.camera = cameras[name]
        scene.render.resolution_y = round(args.resolution * (0.75 if name == "hero" else 0.625))
        scene.render.filepath = str(output / (name + ".png"))
        bpy.ops.render.render(write_still=True)
    print("RENDER_COMPLETE", json.dumps({"objects": len(source["objects"]), "output": str(output)}))


if __name__ == "__main__":
    main()
