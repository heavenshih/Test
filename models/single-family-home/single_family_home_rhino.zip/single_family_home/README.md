# Single-family home — Rhino exterior model

An editable architectural study reconstructed from the supplied front exterior photograph.

## Open in Rhino

Open `single_family_home.3dm` in Rhino 7 or 8. The file uses **metres** and a 0.001 m absolute tolerance. Use **Rendered** or **Shaded** viewport mode to see assigned materials. The saved named views are:

- `01 Front perspective`
- `02 Front elevation`
- `03 Axonometric`
- `04 Rear - inferred`

The file contains **683 objects on 14 layers**: **492 closed Brep solids** for architecture and details, and **191 meshes** primarily for planting and tapered landscape elements. The walls, roof components, siding courses, frames and glazing are individually editable. Window and entry openings are modeled as gaps in the wall geometry.

Hide layers `10 Ornamental grasses`, `11 Shrubs and trees`, and `12 Background planting` for an unobstructed building view. Layer `13 Inferred rear and interiors` groups the simple rear walls and room surfaces used to give the windows depth. Other side walls and roof depths are also inferred, even where they share architectural layers with the observed front elements.

## Scale and scope

Only one exterior photograph was available. **This is an approximate visual model, not a surveyed or construction model.** The scale assumes a 2.50 m garage-door opening. No exact dimensions were supplied.

| Reference dimension | Model value |
| --- | ---: |
| Garage opening width | 2.50 m |
| Main ground-floor frontage | 10.10 m |
| Highest roof coping | 6.925 m above reference ground |
| Lower canopy span | 7.97 m including cap |
| Main building depth | 10.20 m, inferred |

Front faces negative Y; X runs left to right in front elevation; Z is up. The driveway surface is at Z = 0.055 m and the main interior floor slab is at Z = 0.25 m.

The front composition follows the photograph: low garage wing, recessed glazed entry, long dark canopy with timber soffit and downlights, right living-room window, smaller upper charcoal-clad volume, larger upper white volume, three-pane upper window, and the thick roof fascia with timber-lined overhang. Site elements include the driveway, stepping slabs, porch, fences, garden beds, grasses, shrubs and trees.

The full building depth, rear and side elevations, roof construction and interior surfaces are simplified assumptions. There is no developed floor plan, stair layout, structural design, utilities or hidden construction detail. Planting is stylized.

## Included files

- `single_family_home.3dm`: native editable Rhino 7-format model.
- `front.png`: front perspective rendering of the exported geometry.
- `hero.png`: oblique rendering of the exported geometry.
- `build_model.py`: reproducible model generator; requires Python 3.10+ and `rhino3dm`.
- `scene.json`: mesh representation of the same geometry for rendering.
- `render_model.py`: Blender 4.3 rendering script.
- `validation.json`: file read-back and geometry validation results.

The PNGs are generated from the model geometry in Blender, with presentation lighting and procedural material texture. They are not photographs or image-generated replacements. Rhino materials are included; the Blender lighting and procedural textures are specific to the render setup.

## Regenerate or rescale

Install `rhino3dm` into your Python environment, then run:

```sh
python build_model.py
```

To uniformly rescale all dimensions using a known garage opening, for example 2.70 m:

```sh
python build_model.py --garage-width 2.70
```

This rewrites the generated `.3dm` and `scene.json` beside the script. Save any hand-edited Rhino model under another filename first. Alternatively, use Rhino's `Scale` command with the ratio of the measured garage width to 2.50 m.

To reproduce the renderings, use the included Blender script:

```sh
blender -b --python render_model.py -- --scene scene.json --output .
```

## Validation

The written `.3dm` was reopened with `rhino3dm`. All 683 geometry objects were valid, all 492 Breps were closed solids, and all four named views had valid cameras and frustums. Metre units and the frosted entry-panel material were confirmed. The model has not been opened in the Rhino desktop application in this environment.
